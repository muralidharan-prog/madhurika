<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $email = trim($_POST['email']);
    $comment = trim($_POST['comment']);
    if (empty($firstname) || empty($email) || empty($comment)) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: index.php");
        exit();
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Invalid email format.";
        header("Location: index.php");
        exit();
    }
    // Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        // Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication

        $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
        $mail->Username   = 'madhurika1976@gmail.com';              // SMTP username
        $mail->Password   = 'hnflncpyseoehmax';                     // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            // Enable implicit TLS encryption
        $mail->Port       = 465;                                    // TCP port to connect to

        // Recipients
        $mail->setFrom('madhurika1976@gmail.com', 'Madhurika Sankar: Get In Touch');
        $mail->addAddress('madhurika1976@gmail.com', 'Madhurika Sankar: Get In Touch'); // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = 'Get In Touch Contact Form';
        $mail->Body    = '<table width="100%" border="0" cellpadding="0" cellspacing="0" style="Arial, Helvetica, sans-serif;border-collapse: collapse; width: 100%;">
			<tr>
			  <td><table width="100%" border="1" cellpadding="10" cellspacing="10" style="border-collapse: collapse; width: 100%;">
				<tr>
				  <td width="50%" valign="top" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;"><b>First name: </b></p></td>
				  <td width="50%" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;" valign="top"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;">'.$firstname.'</p></td>
				</tr>
				<tr>
				  <td width="50%" valign="top" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;"><b>Last name: </b></p></td>
				  <td width="50%" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;" valign="top"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;">'.$lastname.'</p></td>
				</tr>
				<tr>
				  <td width="50%" valign="top" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;"><b>Email</b></p></td>
				  <td width="50%" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;" valign="top"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;">'.$email.'</p></td>
				</tr>
				<tr>
				  <td width="50%" valign="top" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;"><b>Comment</b></p></td>
				  <td width="50%" style="Arial, Helvetica, sans-serif; border: 1px solid #dddddd; font-size: 16px; line-height: 20px; color: #000000; padding:10px;" valign="top"><p style="Arial, Helvetica, sans-serif; font-size: 16px; line-height: 20px; color: #000000;">'.$comment.'</p></td>
				</tr>
			  </table></td>
			</tr>
		  </table>';


        if ($mail->send()) {
            $_SESSION['status'] = "Thank you for contacting us - Madhurika Sankar";
            header("Location: {$_SERVER['HTTP_REFERER']}");
            exit(0);
        } else {
            $_SESSION['status'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            header("Location: {$_SERVER['HTTP_REFERER']}");
            exit(0);
        }
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    header('Location: index.php');
    exit(0);
}
?>
