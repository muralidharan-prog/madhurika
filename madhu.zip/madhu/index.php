<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Madhurikasankar</title>
		<meta charset="utf-8">
		<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge"><![endif]-->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="robots" content="index, follow"> 
		<meta name="keywords" content="">
		<meta name="description" content=""> 
		<meta name="author" content="Madhurikasankar">
		<link rel="apple-touch-icon" sizes="180x180" href="images/faveicon/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="images/faveicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="images/faveicon/favicon-16x16.png">
		<link rel="icon" href="images/faveicon/favicon.ico" sizes="48x48" />
		<!-- FAVICONS -->
		<!-- Font CSS -->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Teachers:ital,wght@0,400..800;1,400..800&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400..800;1,400..800&family=Teachers:ital,wght@0,400..800;1,400..800&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Goudy+Bookletter+1911&display=swap" rel="stylesheet">

		<!-- Main CSS -->
		<link rel="stylesheet" type="text/css" href="https://unpkg.com/aos@2.3.0/dist/aos.css">
		<link rel="stylesheet" type="text/css" href="css/slick.css">
		<link rel="stylesheet" type="text/css" href="css/slick-theme.css">
		<link rel="stylesheet" href="css/main.css">
	</head>
	<body>
	<div class="overlay"></div>
		<!-- Header Section Start -->
		<section class="headbg">
			<div class="container">
				<div class="headbg__cnt">
					<div class="da_logo" data-aos="fade-left"><img src="images/madurika_logo.svg" alt="Madhurikasankar"></div>
					<div class="da_nav">
						<nav>
							<ul>
								<li><a href="#" title="Home">Home</a></li>
								<li><a href="#about-dustria" title="About Dustria">About Dustria</a></li>
								<li><a href="#author-dustria" title="Author">Author</a></li>
								<li><a href="#da__journals" title="Journals">Journals</a></li>
								<li><a href="#da__contact" title="Get in touch">Get in touch</a></li>							
							</ul>
						</nav>
					</div>
					<div id="mob__nav">
						<div class="menu_bar"><img src="images/menu-bar.svg"></div>
						<div class="menu_close"><img src="images/menu-close.svg"></div>
					</div>
					
				</div>
			</div>
		</section>
		<!-- Header Section End -->
		<!-- Banner Section Start -->
		<Section class="banner_sec">
			<div class="container">
				<div class="da__bnrpt">
					<div class="da__bnrleft">
						<h1 data-aos="fade-up" data-aos-delay="500">Dustria is a speculative fiction novel</h1>

						<p data-aos="fade-up" data-aos-delay="700">Dustria, my debut fantasy, has released! You can order the book now. Happy Reading! </p>

<p data-aos="fade-up" data-aos-delay="700" class="book-links"><a href="https://www.amazon.com/Dustria-Madhurika-Sankar-ebook/dp/B0D2QD364Q/ref=tmm_kin_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.LUyllBL0M8YtERFyXG-nSeuZyQTj9GvPqo70a-xilS6WuDUJr72B7CfL99YfcljMBb1hmsf-oQk0HJjIqL3FJcE8h2AYceuWQUIlLqcdurG5fX1WgHiFAQTMSM_G_pxIlcxnNNeWgyUk-76V0RbY9anVyucCoqdIlVAQgwYpOxIbgs9kv2kyMIDQQ1Fn28a7RENcM_hpHcKcOZotoDDWgwlMoVyHoNfQlAUgfM46z-GWU8bhK9j9ZWdlx94HhAfF.hapEVHCONMLinJtem_kLoA8S6h4GOH3o0ys1CSzBuvA&qid=1734058825&sr=8-1" target="_blank">Amazon</a> <span>|</span> <a href="https://www.amazon.in/Dustria-Madhurika-Sankar-ebook/dp/B0D2QD364Q/ref=sr_1_1?crid=2C9K30IW9RX27&dib=eyJ2IjoiMSJ9.dVPQLifph36SWCak1mrTnQ.xgqLTsOoDWWcyyejEHLdXdslNnbGXgJEXXWCQebvF9w&dib_tag=se&keywords=dustria&qid=1734058767&s=digital-text&sprefix=dustria%2Cdigital-text%2C526&sr=1-1" target="_blank"> Amazon India </a><span>|</span> <a href="https://www.barnesandnoble.com/w/dustria-madhurika-sankar/1146473115?ean=9781988034560" target="_blank">Barnes & Noble </a><span>|</span><a href="https://www.waterstones.com/book/dustria/madhurika-sankar//9781988034584d" target="_blank"> Waterstones (Hardback) </a> 
</p>

						<a data-aos="fade-up" data-aos-delay="900" class="da_cta" href="https://www.amazon.com/Dustria-Madhurika-Sankar-ebook/dp/B0D2QD364Q/ref=sr_1_1?crid=1K057RYWM3KDQ&dib=eyJ2IjoiMSJ9.0515F0WMjWEABbCzR-_dqvFzKmFWD-_4yriVQ57scUt1x0Pb0FQVA0mFVRjpYMuuO2weL6vUS42QyJUzO5aW-QjOu1v8wGzYagVh9ZVhnGzT3BxXg8GmQHH-jDpAgBcmh-dKCE-wX-cIoCXtP7F9Uw.C5PHwK4J1C1FWoMLYcaq7v7vJAV8YFFxColMaK7UL1Y&dib_tag=se&keywords=dustria&qid=1727933311&sprefix=dustria,aps,360&sr=8-1" target="_blank" title="Pre-order now">Order now</a>

						<p data-aos="fade-up" data-aos-delay="750" id="italic">The author encourages E-book purchases to <span class="main_italic">reduce the carbon footprint</span> of publishing print books and of felling trees.Thank you for supporting Mother Earth.</p>

					</div>
					<div class="da__bnrright" data-aos="slide-left" data-aos-easing="ease-out-cubic">
						<img src="images/main_banner.png" alt="Books">
					</div>
				</div>
			</div>
			<div class="container">
				<!-- <h2 data-aos="fade-up" data-aos-delay="500">Testimonials</h2> -->
				<div class="da__tm">
					<div class="da__img"><img src="images/quotes.svg" data-aos="slide-left" alt=""></div>
					<div class="da__tslider"  data-aos="zoom-in">
						<div class="da__titem">
							<p>Dark, disturbing and beautiful.</p>
							<h5>Peter Cox, Litopia</h5>
						</div>
					</div>
				</div>
			</div>
		</Section>


		<!-- Banner Section End -->
		<!-- About Section Start -->
		<Section id="about-dustria">
			<div class="container">
				<h2 data-aos="fade-up" data-aos-delay="500">About Dustria</h2>
				<div class="da__abt">
					<div class="da__abtleft" data-aos="zoom-in-right" data-aos-delay="700" data-aos-easing="ease-out-cubic">
						<img src="images/about.png" alt="Books">
					</div>
					<div class="da__abtright">
						<p data-aos="fade-up" data-aos-delay="800">Sula, a gifted, young surgeon, makes a terrible mistake, and flees to Dustria, a land of monsters and broken things, to punish herself. But she doesn’t really learn from her mistakes until she is presented with a situation where she must choose between confronting her past or continuing down an unexamined path.</p>
						<p data-aos="fade-up" data-aos-delay="900">Dustria is for the questioning reader.  It’s set against the backdrop of a constant exploration of the question: Can we redeem ourselves from terrible mistakes made in our younger years or do we, sometimes, need to find alternate ways to frame our lives in order to grow as individuals and forgive ourselves?</p>
					</div>
				</div>
			
			</div>
		</Section>
		<!-- Get book sections-->
<div class="book-section">
 <p data-aos="fade-up" data-aos-delay="400" class="cta-text">GET YOUR BOOK NOW!</p>
<div data-aos="fade-up" data-aos-delay="400" class="platforms">
        <a href="https://www.amazon.com/Dustria-Madhurika-Sankar-ebook/dp/B0D2QD364Q/ref=tmm_kin_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.LUyllBL0M8YtERFyXG-nSeuZyQTj9GvPqo70a-xilS6WuDUJr72B7CfL99YfcljMBb1hmsf-oQk0HJjIqL3FJcE8h2AYceuWQUIlLqcdurG5fX1WgHiFAQTMSM_G_pxIlcxnNNeWgyUk-76V0RbY9anVyucCoqdIlVAQgwYpOxIbgs9kv2kyMIDQQ1Fn28a7RENcM_hpHcKcOZotoDDWgwlMoVyHoNfQlAUgfM46z-GWU8bhK9j9ZWdlx94HhAfF.hapEVHCONMLinJtem_kLoA8S6h4GOH3o0ys1CSzBuvA&qid=1734058825&sr=8-1" target="_blank"><img src="images/amazoncom.png" alt="Amazon.com"></a>
        <a href="https://www.amazon.in/Dustria-Madhurika-Sankar-ebook/dp/B0D2QD364Q/ref=sr_1_1?crid=2C9K30IW9RX27&dib=eyJ2IjoiMSJ9.dVPQLifph36SWCak1mrTnQ.xgqLTsOoDWWcyyejEHLdXdslNnbGXgJEXXWCQebvF9w&dib_tag=se&keywords=dustria&qid=1734058767&s=digital-text&sprefix=dustria%2Cdigital-text%2C526&sr=1-1" target="_blank"><img src="images/amzz.png" alt="amazonin"></a>
        <a href="https://www.barnesandnoble.com/w/dustria-madhurika-sankar/1146473115?ean=9781988034560" target="_blank"><img src="images/Barnes.png" alt="Barnes"></a>
        <a href="https://www.waterstones.com/book/dustria/madhurika-sankar//9781988034584d" target="_blank"><img src="images/watersronte.png" alt="reedsy"></a>
    </div>
</div>
		<!-- Get End sections-->

		<!-- About Section End -->
		<!-- Author Section Start -->
		<Section id="author-dustria">
			<div class="container">
				<h2 data-aos="fade-up" data-aos-delay="500">About the Author</h2>
				<div class="da__auth">
					<div class="da__authleft">
						<p data-aos="fade-up" data-aos-delay="500">Madhurika Sankar is an impact investor and writer whose work appears in The Hindu, India’s leading national newspaper, in the Op Ed. She’s an engineer with a Master’s in Biotechnology from Columbia University, New York.</p>
						<p data-aos="fade-up" data-aos-delay="600">Madhurika’s short fiction and nonfiction have appeared in literary journals and magazines such as Litro, The Bangalore Review, Rock & Sling, The Avenue, The Bombay Review, Visible, Firewords and the Landing Zone, among others.</p>
						<p data-aos="fade-up" data-aos-delay="700">Her debut novel, Dustria, a fantasy, is forthcoming in the Fall of 2024 from the Canadian publisher of speculative fiction, Vraeyda Literary. She lives in Chennai, India.</p>
						<h4 data-aos="fade-up" data-aos-delay="800">The book was written for, read by and now in memory of my beloved father, N Sankar.</h4>
						<div data-aos="fade-up" data-aos-delay="850"><img src="images/madhurika-sankar.svg"></div>
					</div>
					
					<div class="da__authright" data-aos="slide-up" data-aos-easing="ease-out-cubic">
						<img src="images/dustria-author.png" alt="Author">
					</div>
				</div>
<div data-aos="fade-up" data-aos-delay="500"  class="review-section">
    <div class="center_sec">
	<p>
      The author would be delighted if you delve into the 
      <a href="#" class="highlighted-link">World of Dustria</a>, 
      and take the precious time to <span class="leave_txt">leave a review </span>on these platforms. Thank you!
    </p>
    <div class="platform">
  <a href="https://www.amazon.com/Dustria-Madhurika-Sankar-ebook/dp/B0D2QD364Q/ref=tmm_kin_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.LUyllBL0M8YtERFyXG-nSeuZyQTj9GvPqo70a-xilS6WuDUJr72B7CfL99YfcljMBb1hmsf-oQk0HJjIqL3FJcE8h2AYceuWQUIlLqcdurG5fX1WgHiFAQTMSM_G_pxIlcxnNNeWgyUk-76V0RbY9anVyucCoqdIlVAQgwYpOxIbgs9kv2kyMIDQQ1Fn28a7RENcM_hpHcKcOZotoDDWgwlMoVyHoNfQlAUgfM46z-GWU8bhK9j9ZWdlx94HhAfF.hapEVHCONMLinJtem_kLoA8S6h4GOH3o0ys1CSzBuvA&qid=1734058825&sr=8-1" target="_blank">
    <img src="images/amazonnew.png" alt="Amazon">
  </a>

  <a href="https://www.amazon.in/Dustria-Madhurika-Sankar-ebook/dp/B0D2QD364Q/ref=sr_1_1?crid=2C9K30IW9RX27&dib=eyJ2IjoiMSJ9.dVPQLifph36SWCak1mrTnQ.xgqLTsOoDWWcyyejEHLdXdslNnbGXgJEXXWCQebvF9w&dib_tag=se&keywords=dustria&qid=1734058767&s=digital-text&sprefix=dustria%2Cdigital-text%2C526&sr=1-1" target="_blank">
    <img src="images/amazonin_new.png" alt="amazonnewin">
  </a>

  <a href="https://www.bookbub.com/books/dustria-by-madhurika-sankar" target="_blank">
    <img src="images/bookbub.png" alt="BookBub">
  </a>
  <a href="https://www.goodreads.com/book/show/217518226-dustria" target="_blank">
    <img src="images/goodreads.png" alt="Goodreads">
  </a>
  <a href="https://reedsy.com/discovery/user/madhurikasankar/books" target="_blank">
    <img src="images/reedsy_new.png" alt="Reedsy">
  </a>
</div>
	</div>
  </div>
			</div>
		</Section>
	
		<!-- Author Section End -->
		<!-- Journals Section Start -->
		<Section id="da__journals">
			<h2 data-aos="fade-up" data-aos-delay="500">Published Short Works (Fiction & Nonfiction)</h2>
			<div class="da__jslide">
				<div class="dajslider" data-aos="slide-up" data-aos-easing="ease-out-cubic">
					
					<div class="daj__item">
						<div class="daj__img"><img src="images/forest_1.png" alt="nature"></div>
						<div class="daj__cnt">
							<div class="daj__date">Oct 20, 2021</div>
							<div class="daj__head"><h4>Nonfiction/ Neptune’s Storm in Litro journal</h4></div>
							<div class="daj__para"><p>When I was a little girl, my father would take the family to the hills in the summer as an escape from our perpetually sweltering nook of the world. Kodaikanal. That’s the name of the hill town in which we’d vacation. </p></div>
							<div class="daj__rmore"><a href="https://www.litromagazine.com/nature-issue/neptunes-storm/" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/image3.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">Oct 20, 2021</div>
							<div class="daj__head"><h4>Nonfiction/ Juxtaposition Country in Rock and Sling journal</h4></div>
							<div class="daj__para"><p>After quite a bit of planning, testing, and replanning, we will be launching a new version of the website within the net couple months. We hope to re-engage our readers,</p></div>
							<div class="daj__rmore"><a href="https://rockandsling.com/" target="_blank">Read more</a></div>
						</div>
					</div>
					
					<div class="daj__item">
						<div class="daj__img"><img src="images/magazine.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">May 21, 2021</div>
							<div class="daj__head"><h4>Nonfiction/ Sing Into Place in Visible Magazine</h4></div>
							<div class="daj__para"><p>If I could look back as an old woman, and reflect upon my life, upon moments where everything literally changed by paradigms in but a few minutes, I know the death of my loved ones would rank first.</p></div>
							<div class="daj__rmore"><a href="https://visiblemagazine.com/sing-into-place/" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/indian.png" alt="indian"></div>
						<div class="daj__cnt">
							<div class="daj__date">Nov 20, 2022</div>
							<div class="daj__head"><h4>Nonfiction/ The Discriminatory Indian in The Courtship of Winds journal</h4></div>
							<div class="daj__para"><p>There are people in India who won’t even walk in the shadows cast by certain people: Those who are perpetually shadowed by their own heritage.</p></div>
							<div class="daj__rmore"><a href="https://www.thecourtshipofwinds.org/madhurika-sankar" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/bangalore.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">Oct 20, 2020</div>
							<div class="daj__head"><h4>Fiction/ The Incandescence of Boredom in The Bangalore Review</h4></div>
							<div class="daj__para"><p>Nandu turns five today. I’m given a list of things to get for the birthday party. Crayons, extra paper cups, Scotch tape</p></div>
							<div class="daj__rmore"><a href="https://bangalorereview.com/2020/10/the-incandescence-of-boredom/" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/firewords.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">Oct 20, 2020</div>
							<div class="daj__head"><h4>Fiction/ Maiden Over in Firewords journal</h4></div>
							<div class="daj__para"><p>From the quiet power of nature in A Summer Fjord, to the intense emotional ‘wildness’ of a provoked woman in Maiden Over,</p></div>
							<div class="daj__rmore"><a href="https://firewords.co.uk/fourteen" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/crouching.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">Nov 4, 2021</div>
							<div class="daj__head"><h4>Fiction/ Crouching Liar, Hidden Flagon in Contemporary Literary Review India</h4></div>
							<div class="daj__para"><p>There are unfettered moments from our youth that stand out like shiny stones, little smooth pebbles glistening in a flowing brook, perfectly formed and brilliantly capturing the joy of those times.</p></div>
							<div class="daj__rmore"><a href="https://www.literaryjournal.in/index.php/clri/article/view/681/1057" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/bones.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">June  13, 2022</div>
							<div class="daj__head"><h4>Fiction/ The Bones of Perfection in Drunkmonkeys</h4></div>
							<div class="daj__para"><p>Nandita. That is my name. Born of sun and sand, I found myself on shingled shores, in a way of life very different from mine. People counted Time differently, there. The bread tasted different. The air was tangy.</p></div>
							<div class="daj__rmore"><a href="https://www.drunkmonkeys.us/2017-posts/2022/6/13/fiction-the-bones-of-perfection-madhurika-sankar" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/the_sadow.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">Aug  8, 2021</div>
							<div class="daj__head"><h4>Fiction/ The Shadowseeker in The Tatterhood Review (now The Landing Zone)</h4></div>
							<div class="daj__para"><p>The ink that drips from the tip of my pen fortifies my thoughts into crisp, round words, words that seem sure of their place on the page.</p></div>
							<div class="daj__rmore"><a href="https://tatterhoodreview.wordpress.com/the-shadowseeker-by-madhurika-sankar/" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/cauldron.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">Aug  1, 2019</div>
							<div class="daj__head"><h4>Op-Ed/ Cauldron of sexual misconduct</h4></div>
							<div class="daj__para"><p>As India boldly leaps into space and proudly increases its tiger population, feats all deserving praise, foreign investors leave this increasingly disturbing landscape of cultural hegemony and faux-nationalistic fervour.</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/cauldron-of-sexual-misconduct/article28775461.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/weare_smaller.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">May  1, 2019</div>
							<div class="daj__head"><h4>Op-Ed/ We are all similar</h4></div>
							<div class="daj__para"><p> silhouettes vector. Social icon. Flat style design We are living in an increasingly polarised world. When we draw lines in the sand to demarcate our socio-cultural and religious identities, the consequences are violent.</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/we-are-all-similar/article26995095.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/a callous.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">May  20, 2019</div>
							<div class="daj__head"><h4>Op-Ed/ A callous response</h4></div>
							<div class="daj__para"><p>In India, the informal sector accounts for over 80% of non-agricultural employment. This is a staggering number that has had unprecedented significance in the past few weeks,</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/a-callous-response/article31626058.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/the_anatomy.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">Apirl  23, 2019</div>
							<div class="daj__head"><h4>Op-Ed/ The anatomy of beauty</h4></div>
							<div class="daj__para"><p>With great hotness comes great responsibility,” says the adorably vapid Haley Dunphy on the hit U.S. sitcom Modern Family.</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/the-anatomy-of-beauty/article26914228.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/ironises.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">June  24, 2020</div>
							<div class="daj__head"><h4>Op-Ed/ Crop of ironies</h4></div>
							<div class="daj__para"><p>It is ironic that it took a devastating pandemic to force the government’s hand for long-overdue agrarian reforms. Amendments have been made to the Essential Commodities Act, 1955.</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/crop-of-ironies/article62107863.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/deconstructing.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">March  25, 2019</div>
							<div class="daj__head"><h4>Op-Ed/ Deconstructing addiction</h4></div>
							<div class="daj__para"><p>Acclaimed musician Sarah McLachlan sings in her addiction anthem Angel: “You are pulled from the wreckage of your silent reverie.</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/deconstructing-addiction/article26626591.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/pipe_dreams.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date">August 12, 2019 </div>
							<div class="daj__head"><h4>Op-Ed/ Pipe dreams for water transfer</h4></div>
							<div class="daj__para"><p>Last month, the ‘Chennai water train’ made its poignant, slow arrival into the city, carrying 2.5 million litres of water for its parched residents.</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/pipe-dreams-for-water-transfer/article28984775.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/creating _hope.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date"> June 24, 2019 </div>
							<div class="daj__head"><h4>Op-Ed/ Creating sanctuaries of hope for migrant workers</h4></div>
							<div class="daj__para"><p>There is a wilderness within our borders. It’s so vast that it covers an entire nation, with around 100 million inhabitants, one-fifth of our labour force.</p></div>
							<div class="daj__rmore"><a href="https://www.thehindu.com/opinion/op-ed/creating-sanctuaries-of-hope-for-migrant-workers/article28118160.ece" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/red _and_surreal.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date"> June 24, 2007 </div>
							<div class="daj__head"><h4>Review/ Real and Surreal</h4></div>
							<div class="daj__para"><p> k im Ki-Young's "lodo" juxta- K poses South Korea's post- War state of flux (caused by modernisation and challenges to cultural identity) and a surreal world with demons, sha- mans, occult and fantastical is- and.</p></div>
							<div class="daj__rmore"><a href="https://www.inkocentre.org/press/2007/Real_and_Surreal.pdf" target="_blank">Read more</a></div>
						</div>
					</div>
					<div class="daj__item">
						<div class="daj__img"><img src="images/non-fitctions.png" alt=""></div>
						<div class="daj__cnt">
							<div class="daj__date"> oct 20, 2001 </div>
							<div class="daj__head"><h4>Nonfiction/ Chasing Butterflies in The Avenue journal</h4></div>
							<div class="daj__para"><p>My father would make business trips to Australia when I was a child. I knew this land to be different from America, the other place he would travel to, because he’d said, though there were white people here, also, everything was upside down.</p></div>
							<div class="daj__rmore"><a href="https://www.inkocentre.org/press/2007/Real_and_Surreal.pdf" target="_blank">Read more</a></div>
						</div>
					</div>
				</div>
			</div>
		</Section>
		<!-- Journals Section End -->
		<!-- Testimonials Section Start -->
		 <!-- <Section id="da__testimonials">
			<div class="container">
				<h2 data-aos="fade-up" data-aos-delay="500">Testimonials</h2>
				<div class="da__tm">
					<div><img src="images/quotes.svg" data-aos="slide-left" alt=""></div>
					<div class="da__tslider"  data-aos="zoom-in">
						<div class="da__titem">
							<p>Dark, disturbing and beautiful.</p>
							<h5>Peter Cox, Litopia (The world's oldest writing community)</h5>
						</div>
					</div>
				</div>
			</div>
		</Section>   -->
		<!-- Testimonials Section End -->
		<!-- Contact Section Start -->
		<Section id="da__contact">
			<div class="container">
				<h2 data-aos="fade-up" data-aos-delay="500">Get in touch</h2>
				<div class="da__git" data-aos="fade-up" data-aos-delay="800">
					<form action="sendmail.php" method="post" id="submit_form">
						<div class="form_group">
							<input type="text" id="firstname" name="firstname" placeholder="First name" required>
							<input type="text" id="lastname" name="lastname" placeholder="Last name">
						</div>
						<div class="form_group">
							<input type="email" id="email" name="email" placeholder="Email address" required>
							<!--<input type="tel" id="phone" name="phone" placeholder="Mobile number" required> -->
						</div>
						<div class="form_group">
							<textarea name="comment" id="comment" placeholder="Message" required></textarea>    
						</div>
						<div class="form_group">
							<input type="submit" value="Submit" name="submit" class="submit" id="submit">
						</div>
						<div class="form_group">
							<span id="error_message" class="text-danger">&nbsp;</span>  
							<span id="success_message" class="text-success">&nbsp;</span>
						</div>
					</form>
				</div>
			</div>
		</Section>
		<!-- Contact Section End -->
		<!-- Footer Section End -->
		<footer>
			<div class="container">
				<div class="foot-top">
					<div class="foot__left">
						<div data-aos="fade-up" data-aos-delay="300" class="foot_logo"><img src="images/madurika_logo.svg" alt="Madhurikasankar"></div>
						<ul>
							<li data-aos="zoom-in" data-aos-delay="400"><a href="https://x.com/MadhurikaSankar"target="_blank"><img src="images/twitter.svg" alt=""></a></li>
							<li data-aos="zoom-in" data-aos-delay="500"><a href="https://www.instagram.com/madsanks/ "target="_blank"><img src="images/instagram.svg" alt=""></a></li>
							<li data-aos="zoom-in" data-aos-delay="600"><a href="https://www.linkedin.com/in/madhurika-sankar-0424862/" target="_blank"><img src="images/linkedin.svg" alt=""></a></li>
						</ul>
					</div>
					<div class="foot__right" data-aos="fade-up" data-aos-delay="300">
						<h6>Sign up for newsletter</h6>
						<form action="newslettermail.php" method="post" id="submit_form">
							<div class="form_group">
								<input type="email" id="email" name="email" placeholder="Email address" required>
							</div>
							<div class="form_group">
								<input type="submit" value="Submit" name="submit" class="submit">
							</div>
					</form>
					</div>
				</div>
				<div class="foot-brm">
					<p>&copy; Copyrights 2024 . All Rights Reserved.</p>
					<p>Powered by <a href="https://www.jamoons.com/" target="_blank" rel="noopener">Jamoons Digital</a></p>
				</div>
			</div>
		</footer>
		<!-- Footer Section End -->
		<!-- Jquery JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
		<script type="text/javascript" src="js/slick.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
		<script>
			var messageText = "<?= $_SESSION['status'] ?? ''; ?>";
			if(messageText != '') {
				Swal.fire({
					title: "Thank you!",
					text: messageText,
					icon: "success"
				});
				<?php unset($_SESSION['status']); ?>
			}

		</script>
		
		<script>
			jQuery(document).ready(function($) {
				$('.dajslider').slick({
					infinite: true,
					dots: false,
					speed: 1000,
					slidesToShow: 3,
					slidesToScroll: 1,
					autoplay: false,
					autoplaySpeed: 1500,
					centerMode: true,
					centerPadding: '170px',
					arrows: true,
					responsive: [{
					  breakpoint: 1400,
					  settings: {
						slidesToShow: 2,
						slidesToScroll: 1
					  }
					},
					{
					   breakpoint: 1030,
					   settings: {
						  slidesToShow: 1,
						  slidesToScroll: 1
					   }
					},
					{
					   breakpoint: 880,
					   settings: {
						 centerMode: true,
						centerPadding: '80px',
						  slidesToShow: 1,
						  slidesToScroll: 1
					   }
					},
					{
					   breakpoint: 767,
					   settings: {
						centerMode: true,
						centerPadding: '40px',
						  slidesToShow: 1,
						  slidesToScroll: 1
					   }
					}]
				});
				
				$('.da__tslider').slick({
					infinite: true,
					dots: true,
					speed: 1500,
					slidesToShow: 1,
					slidesToScroll: 1,
					autoplay: true,
					autoplaySpeed: 2000,
					arrows: false
				});
			// menu
			$('#mob__nav').click(function(){
			$(this).toggleClass('open');
			$('.da_nav').toggleClass('menuopen');
			$('.overlay').toggleClass('bgshadow');
		});
			});
		// Aos Animation
		AOS.init({
		  duration: 1200,
		  once: true,
		})
		
		//Sticky Header
		const header = document.querySelector(".headbg");
const toggleClass = "is-sticky";

window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset;
  if (currentScroll > 150) {
    header.classList.add(toggleClass);
  } else {
    header.classList.remove(toggleClass);
  }
});
		</script>

	</body>
</html>